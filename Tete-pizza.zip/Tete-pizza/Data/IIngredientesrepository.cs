using System.Dynamic;
using TetePizza.Model;

namespace TetePizza.Data
{
    public interface IIngredientesRepository
    {

      List<Ingredientes> GetAll();

      Ingredientes Get(int id);
      
    }
}
