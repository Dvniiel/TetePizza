namespace TetePizza.Model;

public class Usuario
{
    public int idUsuario { get; set; }
    
    public string?  nombre { get; set; }

    public string? direccion { get; set; }
}