namespace TetePizza.Model;

public class Pizza {

    public int idPizza { get; set;}

    public string? nombrePizza { get; set; }

    public double precioPizza {get; set;}

    public List<Ingredientes> Ingredients {get; set;}

}