﻿namespace TetePizza.Model;

public class Pedidos
{
    public int idPedido { get; set; }
    public List<Pizza> Pizzas { get; set; } = new List<Pizza>();
    public double precioPedido { get; set; }
    public Usuario? User { get; set; }
}